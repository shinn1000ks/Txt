import org.rabbitconverter.rabbit.Rabbit;
import java.lang.reflect.Method;
public class RabbitTest {
    public static void main(String[] args) {
        for (Method m : Rabbit.class.getMethods()) {
            System.out.println(m.getName());
        }
    }
}
