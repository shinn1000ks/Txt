package com.example.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.pdf.ConversionState
import com.example.pdf.PdfViewModel
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import androidx.core.content.FileProvider

@Composable
fun HomeScreen(navController: NavController, viewModel: PdfViewModel, geminiApiKey: String) {
    val context = LocalContext.current
    val state by viewModel.conversionState.collectAsState()

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.convertPdf(context, uri, geminiApiKey)
        }
    }

    LaunchedEffect(state) {
        if (state is ConversionState.Success) {
            navController.navigate("editor")
        }
    }

    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text("Myanmar PDF to TXT") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentAlignment = Alignment.Center
        ) {
            when (state) {
                is ConversionState.Idle, is ConversionState.Error -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (state is ConversionState.Error) {
                            Text(
                                text = "Error: ${(state as ConversionState.Error).message}",
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier.padding(16.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                        
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = "PDF Icon",
                            modifier = Modifier.size(72.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(24.dp))
                        Button(
                            onClick = { launcher.launch("application/pdf") },
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text("Select PDF")
                        }
                        Text(
                            "Extracts text locally. Uses Gemini OCR for scanned pages.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 32.dp)
                        )
                    }
                }
                is ConversionState.Extracting -> {
                    val progressState = state as ConversionState.Extracting
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Extracting page ${progressState.current} of ${progressState.total}...")
                    }
                }
                else -> {}
            }
        }
    }
}

@Composable
fun EditorScreen(navController: NavController, viewModel: PdfViewModel) {
    val state by viewModel.conversionState.collectAsState()
    val context = LocalContext.current
    var text by remember { mutableStateOf("") }
    
    LaunchedEffect(state) {
        if (state is ConversionState.Success) {
            text = (state as ConversionState.Success).text
        }
    }
    
    val saveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                    OutputStreamWriter(outputStream).use { writer ->
                        writer.write(text)
                    }
                }
                Toast.makeText(context, "Saved successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to save", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            @OptIn(ExperimentalMaterial3Api::class)
            TopAppBar(
                title = { Text("Edit Text") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                actions = {
                    IconButton(onClick = {
                        val shareIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, text)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share text"))
                    }) {
                        Icon(Icons.Default.Share, contentDescription = "Share")
                    }
                    IconButton(onClick = {
                        saveLauncher.launch("document.txt")
                    }) {
                        Icon(Icons.Default.Save, contentDescription = "Save as TXT")
                    }
                }
            )
        }
    ) { paddingValues ->
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            textStyle = MaterialTheme.typography.bodyLarge
        )
    }
}
