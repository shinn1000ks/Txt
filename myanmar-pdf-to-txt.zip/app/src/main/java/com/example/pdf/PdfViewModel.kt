package com.example.pdf

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class ConversionState {
    object Idle : ConversionState()
    data class Extracting(val current: Int, val total: Int) : ConversionState()
    data class Success(val text: String) : ConversionState()
    data class Error(val message: String) : ConversionState()
}

class PdfViewModel : ViewModel() {
    private val _conversionState = MutableStateFlow<ConversionState>(ConversionState.Idle)
    val conversionState: StateFlow<ConversionState> = _conversionState

    fun convertPdf(context: Context, uri: Uri, geminiApiKey: String) {
        _conversionState.value = ConversionState.Extracting(0, 1)
        viewModelScope.launch {
            try {
                val processor = PdfProcessor(context, geminiApiKey)
                val rawText = processor.extractText(uri) { current, total ->
                    _conversionState.value = ConversionState.Extracting(current, total)
                }
                
                // Normalize Zawgyi to Unicode
                val normalizedText = MyanmarTextNormalizer.normalizeToUnicode(rawText)
                
                _conversionState.value = ConversionState.Success(normalizedText)
            } catch (e: Exception) {
                _conversionState.value = ConversionState.Error(e.message ?: "Unknown error")
            }
        }
    }
    
    fun reset() {
        _conversionState.value = ConversionState.Idle
    }
}
