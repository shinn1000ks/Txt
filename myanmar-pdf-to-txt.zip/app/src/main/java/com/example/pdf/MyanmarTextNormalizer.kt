package com.example.pdf

import com.google.myanmartools.ZawgyiDetector
import org.rabbitconverter.rabbit.Rabbit

object MyanmarTextNormalizer {
    private val detector = ZawgyiDetector()

    fun normalizeToUnicode(text: String): String {
        if (text.isBlank()) return text
        
        // Detect if text is Zawgyi
        val score = detector.getZawgyiProbability(text)
        
        return if (score > 0.9) { // High probability of being Zawgyi
            Rabbit.zg2uni(text)
        } else {
            text // Likely Unicode already
        }
    }
}
